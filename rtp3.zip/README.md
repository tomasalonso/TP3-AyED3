Notas:

* Compilación: sobre la carpeta de código ejecutar make.

* En la carpeta de código se encuentra elizondo.cpp, un intento de interfaz para que nuestro equipo se comunique con
Elizondo provisto por la cátedra que no logramos hacer funcionar.

* En el ejecutable del algoritmo genético, el tiempo se imprimen por la salida estándar y las generaciones y parámetros de entrada por salida de error.
